/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 10:01:34 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/26 17:12:29 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	show_prompt(t_env *env)
{
	char	*prompt;
	char	*formatted;

	prompt = env_get(env, VAR_PROMPT);
	prompt = (prompt ? prompt : DEFAULT_PROMPT);
	formatted = format_prompt(env, prompt);
	ft_putstr(formatted);
	free(formatted);
}
