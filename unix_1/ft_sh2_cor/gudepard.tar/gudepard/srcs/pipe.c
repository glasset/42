/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipe.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/23 23:20:02 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 19:41:58 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	piped_final(t_ast *left, t_ast *right, int fds[6], t_env *env)
{
	pid_t	pid;

	pid = fork();
	if (pid != -1)
	{
		if (pid == 0)
			exec_one_piped(left, env, fds);
		else
		{
			dup2(fds[0], STDIN);
			dupif(fds[5], STDOUT);
			close_all(fds);
			close_all(fds + 2);
			close_all(fds + 4);
			ast_exec_cmd(right, env, 1);
			exit(1);
		}
	}
	else
		shell_error(ERR_FORK_FAILED, 0);
}

static void	piped_2(t_ast *left, t_ast *right, int prev_fds[6], t_env *env)
{
	int		fds[4];
	pid_t	pid;

	pid = fork();
	if (pid != -1)
	{
		if (pid == 0)
			exec_one_piped(left, env, prev_fds);
		else
		{
			if (!pipe(fds))
			{
				close_all(prev_fds + 2);
				fds[2] = prev_fds[0];
				fds[3] = prev_fds[1];
				pipe_ast_node(right, fds, env);
			}
			else
				shell_error(ERR_PIPE_FAILED, 0);
			exit(1);
		}
	}
	else
		shell_error(ERR_FORK_FAILED, 0);
}

static void	r_redirect_in_pipe(t_ast *node, int oflags, int fds[6], t_env *env)
{
	t_token	*token;

	if (!ast_is_node_type(node->right->right, WORD))
		ambiguous_redirect_error(node->right->right, 1);
	token = (t_token *)(node->right->right->tokens->content);
	fds[5] = open_file(token->value, oflags, CREATE_PERMISSIONS);
	piped_final(node->left, node->right->left, fds, env);
}

void		pipe_ast_node(t_ast *node, int fds[6], t_env *env)
{
	if (ast_is_node_type(node->right, WORD))
		piped_final(node->left, node->right, fds, env);
	else if (ast_is_node_type(node->right, OP_PIPE))
		piped_2(node->left, node->right, fds, env);
	else if (ast_is_node_type(node->right, OP_REDIRECT_RIGHT))
		r_redirect_in_pipe(node, TRUNC_OFLAGS, fds, env);
	else if (ast_is_node_type(node->right, OP_REDIRECT_RIGHT2))
		r_redirect_in_pipe(node, APPEND_OFLAGS, fds, env);
	else
		ambiguous_redirect_error(node->right, 1);
}

void		ast_exec_piped(t_ast *node, t_env *env, int fd_in)
{
	int		fds[6] = {-1, -1, -1, -1, -1, -1};
	pid_t	pid;

	fds[2] = fd_in;
	if (!pipe(fds))
	{
		pid = fork();
		if (pid != -1)
		{
			if (pid == 0)
				pipe_ast_node(node, fds, env);
			else
			{
				close_all(fds);
				closeif(fd_in);
				wait(0);
			}
		}
		else
			shell_error(ERR_FORK_FAILED, 0);
	}
	else
		shell_error(ERR_PIPE_FAILED, 0);
}
