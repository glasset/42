/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reduce_path.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/28 15:40:42 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/29 16:40:26 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	*reduce_path(t_env *env, const char *path)
{
	char	*home;
	char	*reduced;

	reduced = 0;
	home = env_get(env, VAR_HOME);
	if (home)
		reduced = str_replace(path, home, HOME_SHORTCUT);
	return (reduced);
}
