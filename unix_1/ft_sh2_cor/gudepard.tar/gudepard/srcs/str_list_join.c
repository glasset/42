/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   str_list_join.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 15:36:56 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/26 17:32:54 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	*str_list_join(t_list *list)
{
	size_t	total;
	size_t	len;
	char	*str;
	t_list	*it;

	total = 0;
	it = list;
	while (it)
	{
		total += ft_strlen((char *)it->content);
		it = it->next;
	}
	str = (char *)malloc(sizeof(char) * (total + 1));
	str[total] = '\0';
	it = list;
	while (it)
	{
		len = ft_strlen((char *)it->content);
		total -= len;
		ft_strncpy(str + total, (char *)it->content, len);
		it = it->next;
	}
	return (str);
}
