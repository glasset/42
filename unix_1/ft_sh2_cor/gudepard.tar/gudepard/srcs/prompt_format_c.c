/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt_format_c.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 16:16:22 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/28 15:40:33 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void		prompt_format_c(t_env *env, t_list **str)
{
	char	*pwd;
	char	*reduced;

	pwd = env_get(env, VAR_PWD);
	if (pwd)
	{
		reduced = reduce_path(env, pwd);
		if (reduced)
			ft_lstadd(str, ft_lstnew(reduced, ft_strlen(reduced) + 1));
		else
			ft_lstadd(str, ft_lstnew(pwd, ft_strlen(pwd) + 1));
		free(reduced);
	}
}
