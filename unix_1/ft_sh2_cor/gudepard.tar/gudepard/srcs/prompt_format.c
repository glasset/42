/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt_format.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 16:37:51 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/23 21:25:59 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void			process_percent(t_env *env, const char **fmt, t_list **str)
{
	t_prompt_proc	proc;
	char			c;

	c = **fmt;
	proc = (t_prompt_proc)ft_map_get(*prompt_format_map(), &c, char_hash);
	if (proc)
	{
		++(*fmt);
		proc(env, str);
	}
}

static void			process_char(t_env *env, const char **fmt, t_list **str)
{
	char			*one;

	if (**fmt == '{')
	{
		++(*fmt);
		if (**fmt == '$')
			process_value(env, fmt, str);
		else
			process_color(fmt, str);
	}
	else if (**fmt == '%')
	{
		++(*fmt);
		process_percent(env, fmt, str);
	}
	else
	{
		one = ft_strsub((*fmt)++, 0, 1);
		ft_lstadd(str, ft_lstnew(one, 2));
		free(one);
	}
}

char				*format_prompt(t_env *env, const char *fmt)
{
	t_list			*str;
	char			*prompt;

	str = 0;
	while (*fmt)
		process_char(env, &fmt, &str);
	prompt = str_list_join(str);
	ft_lstdel(&str, (t_deleter)free);
	return (prompt);
}
