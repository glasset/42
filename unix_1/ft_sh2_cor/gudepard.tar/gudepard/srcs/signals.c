/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signals.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 17:45:02 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 18:55:08 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void		on_sigint(int sig)
{
	t_env	*env;

	UNUSED(sig);
	env = get_env();
	ft_putchar('\n');
	if (!env->running || env->heredoc)
		show_prompt(env);
	env->heredoc = 0;
}
