/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 03:39:41 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 20:56:43 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	load_config(t_env *env, const char *file_name)
{
	int		fd;
	char	*line;

	fd = open(file_name, O_RDONLY);
	if (fd > 0)
	{
		while (get_next_line(fd, &line) == 1)
		{
			execute_line(line, env);
			free(line);
		}
		close(fd);
	}
}

static void	inc_shlvl(t_env *env)
{
	char	*shlvl;
	int		shlvl_value;

	shlvl = env_get(env, VAR_SHELL_LVL);
	if (shlvl)
	{
		shlvl_value = ft_atoi(shlvl);
		shlvl = ft_itoa(shlvl_value + 1);
		env_set(env, VAR_SHELL_LVL, shlvl);
		free(shlvl);
	}
	else
		env_set(env, VAR_SHELL_LVL, "1");
}

static void	force_pwd(t_env *env)
{
	char	*pwd;
	char	*opwd;

	pwd = env_get(env, VAR_PWD);
	opwd = env_get(env, VAR_OLDPWD);
	if (!pwd)
	{
		pwd = getcwd(0, 0);
		env_set(env, VAR_PWD, pwd);
		free(pwd);
	}
	if (!opwd)
	{
		pwd = env_get(env, VAR_PWD);
		if (pwd)
			env_set(env, VAR_OLDPWD, pwd);
	}
}

static void	init(t_env *env, int argc, char **argv)
{
	signal(SIGINT, on_sigint);
	init_env_vars(env);
	inc_shlvl(env);
	force_pwd(env);
	cd(env, 0);
	if (argc >= 2)
		load_config(env, argv[1]);
	show_prompt(env);
}

int			main(int argc, char **argv)
{
	char	*line;
	t_env	*env;

	env = get_env();
	init(env, argc, argv);
	while (get_next_line(STDIN, &line) == 1)
	{
		env->running = 1;
		execute_line(line, env);
		env->running = 0;
		show_prompt(env);
		free(line);
	}
	ft_putchar('\n');
	free_env(env);
	return (0);
}
