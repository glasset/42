/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   functors.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/21 18:48:22 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/21 20:09:25 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void			env_map_del(void *key, void *value)
{
	free(key);
	free(value);
}

void			increment(void *data, void *count)
{
	size_t		*i;

	UNUSED(data);
	i = (size_t *)count;
	++(*i);
}

void			map_add_env_to_array(void *data, void *p_array)
{
	t_map_entry	*entry;
	char		***array;

	entry = (t_map_entry *)data;
	array = (char ***)p_array;
	**array = join_env(entry->key, entry->value);
	++(*array);
}

void			map_copy_one(void *data, void *other_map)
{
	t_map_entry	*entry;
	t_map_entry	new_entry;
	t_map		*map;

	entry = (t_map_entry *)data;
	map = (t_map *)other_map;
	new_entry.key = ft_strdup(entry->key);
	new_entry.value = ft_strdup(entry->value);
	ft_map_insert(*map, new_entry, ft_djb2);
}

void			map_print_env_one(void *data, void *p_env)
{
	t_env		*env;
	t_map_entry	*entry;

	entry = (t_map_entry *)data;
	env = (t_env *)p_env;
	print_env_one(env, entry->key, entry->value);
}
