/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chdir.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 07:53:23 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/22 10:45:04 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static int	check_path(const char *path, const char *initial)
{
	if (access(path, F_OK))
	{
		builtin_error(CD_COMMAND, ERR_FILE_NON_EXISTING, initial);
		return (0);
	}
	if (access(path, X_OK))
	{
		builtin_error(CD_COMMAND, ERR_DENIED, initial);
		return (0);
	}
	return (1);
}

int			cd(t_env *env, const char *path)
{
	char	*full_path;
	char	*from;
	int		ret;

	ret = 0;
	from = ((path && *path == '/') ? 0 : env_get(env, VAR_PWD));
	full_path = path_join(from, path);
	if (check_path(full_path, path))
	{
		if (!chdir(full_path))
		{
			from = env_get(env, VAR_PWD);
			if (from)
				env_set(env, VAR_OLDPWD, from);
			env_set(env, VAR_PWD, full_path);
			ret = 1;
		}
		else
			builtin_error(CD_COMMAND, ERR_UNKNOWN, path);
	}
	free(full_path);
	return (ret);
}

static void	_cd(t_env *env, const char *raw_path)
{
	char	*opwd;
	char	*path;

	if (!ft_strcmp(raw_path, "-"))
	{
		opwd = env_get(env, VAR_OLDPWD);
		if (opwd)
		{
			path = reduce_path(env, opwd);
			if (path)
				ft_putendl(path);
			else
				ft_putendl(opwd);
			free(path);
			cd(env, opwd);
		}
	}
	else if (!ft_strncmp(raw_path, HOME_SHORTCUT, sizeof(HOME_SHORTCUT) - 1))
	{
		path = str_replace(raw_path, HOME_SHORTCUT, env_get(env, VAR_HOME));
		cd(env, path);
		free(path);
	}
	else
		cd(env, raw_path);
}

static void	cd_replace(t_env *env, const char *old, const char *new)
{
	char	*replaced;
	char	*reduced;
	char	*pwd;

	pwd = env_get(env, VAR_PWD);
	if (pwd)
	{
		replaced = str_replace(pwd, old, new);
		if (replaced)
		{
			if (cd(env, replaced))
			{
				reduced = reduce_path(env, replaced);
				if (reduced)
					ft_putendl(reduced);
				else
					ft_putendl(replaced);
				free(reduced);
			}
		}
		else
			builtin_error(CD_COMMAND, ERR_NOT_IN_PWD, old);
		free(replaced);
	}
}

void		b_cd(t_env *env, size_t argc, char **args)
{
	char	*path;

	if (argc <= 2)
	{
		path = (argc == 2 ? args[1] : env_get(env, VAR_HOME));
		if (path)
			_cd(env, path);
		else
			builtin_error(CD_COMMAND, ERR_NO_HOME, 0);
	}
	else if (argc == 3)
		cd_replace(env, args[1], args[2]);
	else
		builtin_error(CD_COMMAND, ERR_TOO_MANY_ARGS, 0);
}
