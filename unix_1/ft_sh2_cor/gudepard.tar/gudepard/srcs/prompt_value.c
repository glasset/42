/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt_value.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 16:45:56 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/26 16:46:41 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	process_value(t_env *env, const char **fmt, t_list **str)
{
	char	*end;
	char	*sub;
	char	*value;

	++(*fmt);
	end = ft_strchr(*fmt, '}');
	if (end)
	{
		sub = ft_strsub(*fmt, 0, end - *fmt);
		value = env_get(env, sub);
		value = (value ? ft_strdup(value) : ft_strnew(0));
		ft_lstadd(str, ft_lstnew(value, ft_strlen(value) + 1));
		free(value);
		free(sub);
		*fmt = end + 1;
	}
}
