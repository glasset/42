/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lexer3.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/24 23:11:30 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/24 23:17:07 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static size_t	count_char(const char *str, size_t len, char c)
{
	size_t		n;

	n = 0;
	while (len--)
		n += (*str++ == c);
	return (n);
}

char			*extract_word(const char *start, size_t len)
{
	size_t		dquote_count;
	char		*word;
	char		*iword;

	dquote_count = count_char(start, len, '"');
	word = (char *)malloc(sizeof(char) * (len - dquote_count + 1));
	word[len - dquote_count] = '\0';
	iword = word;
	if (word)
	{
		while (len--)
		{
			if (*start != '"')
				*iword++ = *start;
			++start;
		}
	}
	return (word);
}
