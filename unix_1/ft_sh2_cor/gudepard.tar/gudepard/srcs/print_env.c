/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_env.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 08:59:55 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/21 20:09:09 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	colored(t_env *env, const char *str, const char *key, int def)
{
	char	*value;
	int		color;

	value = env_get(env, key);
	color = (value ? ft_atoi(value) : def);
	ft_setfgcolor(color);
	ft_putstr(str);
	ft_resetcolor();
}

void		print_env_one(t_env *env, const char *key, const char *value)
{
	colored(env, key, VAR_ENV_KEY_COLOR, 2);
	colored(env, "=", VAR_ENV_SEPARATOR_COLOR, 255);
	colored(env, value, VAR_ENV_VALUE_COLOR, 202);
	ft_putchar('\n');
}

static void	env_all(t_env *env, char **additional, int ignore_inherited)
{
	char	*sep_index;
	char	*key;

	if (!ignore_inherited)
		ft_map_foreach(env->vars, map_print_env_one, env);
	while (*additional)
	{
		sep_index = ft_strchr(*additional, '=');
		key = ft_strsub(*additional, 0, sep_index - *additional);
		print_env_one(env, key, sep_index + 1);
		free(key);
		++additional;
	}
}

static int	has_inherit_option(size_t argc, char **args, char *parse_error)
{
	size_t	i;
	size_t	j;
	int		inherit;

	inherit = 1;
	i = 1;
	while (i < argc && *args[i] == '-')
	{
		j = 1;
		while (args[i][j])
		{
			if (args[i][j] == 'i')
				inherit = i + 1;
			else if (args[i][j] != '-')
			{
				*parse_error = args[i][j];
				return (1);
			}
			++j;
		}
		++i;
	}
	return (inherit);
}

void		b_env(t_env *env, size_t argc, char **args)
{
	size_t	i;
	int		inherit_index;
	char	parse_error;
	int		utility;

	parse_error = 0;
	inherit_index = has_inherit_option(argc, args, &parse_error);
	if (parse_error)
		builtin_error(ENV_COMMAND, ERR_ILLEGAL_OPTION, &parse_error);
	else
	{
		i = inherit_index;
		utility = 0;
		while (i < argc)
			utility += (ft_strchr(args[i++], '=') == 0);
		if (!utility)
			env_all(env, args + inherit_index, (inherit_index > 1));
		else
			env_utility(env, args + inherit_index, (inherit_index > 1));
	}
}
