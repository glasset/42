/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lexer2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/23 19:29:27 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/25 14:38:25 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void		ignore_whitespace(char **stream)
{
	while (**stream == ' ' || **stream == '\t')
		++(*stream);
}

static int	read_sym(char **stream, t_token *token_in, t_token *token_out)
{
	size_t	len;

	len = ft_strlen(token_in->value);
	if (!ft_strncmp(*stream, token_in->value, len))
	{
		*stream += len;
		token_out->type = token_in->type;
		token_out->value = ft_strdup(token_in->value);
		return (1);
	}
	return (0);
}

int			read_operator(char **stream, t_token *token)
{
	size_t			i;
	static t_token	operators[] =
	{
		{OP_SEMI_COLON, ";"},
		{OP_PIPE, "|"},
		{OP_REDIRECT_LEFT2, "<<"},
		{OP_REDIRECT_RIGHT2, ">>"},
		{OP_REDIRECT_LEFT, "<"},
		{OP_REDIRECT_RIGHT, ">"}
	};

	i = 0;
	while (i < sizeof(operators) / sizeof(t_token))
	{
		if (read_sym(stream, operators + i, token))
			return (1);
		++i;
	}
	return (0);
}

static int	is_word_char(char c)
{
	return (ft_isalnum(c)
			|| ft_strchr(WORD_CHARS, c));
}

int			read_word(char **stream, t_token *token)
{
	char	*save;
	int		in_dquote;

	in_dquote = 0;
	save = *stream;
	while (**stream && (in_dquote || is_word_char(**stream)))
	{
		if (**stream == '"')
			in_dquote = !in_dquote;
		++(*stream);
	}
	if (*stream - save > 0 && !in_dquote)
	{
		token->type = WORD;
		token->value = extract_word(save, *stream - save);
		return (1);
	}
	if (in_dquote)
		shell_error(ERR_MISSING_DQUOTE, 0);
	*stream = save;
	return (0);
}
