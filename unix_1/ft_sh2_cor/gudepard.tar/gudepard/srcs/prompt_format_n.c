/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt_format_n.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 23:08:13 by gudepard          #+#    #+#             */
/*   Updated: 2013/12/26 23:14:05 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	prompt_format_n(t_env *env, t_list **str)
{
	char	*user_name;

	user_name = env_get(env, VAR_USER);
	if (user_name)
		ft_lstadd(str, ft_lstnew(user_name, ft_strlen(user_name) + 1));
}
