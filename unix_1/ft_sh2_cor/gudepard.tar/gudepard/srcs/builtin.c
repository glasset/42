/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 07:39:49 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/19 20:15:07 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void			add_to_map(t_map *map, char *key, t_cmd cmd)
{
	t_map_entry		entry;

	entry.key = key;
	entry.value = cmd;
	ft_map_insert(*map, entry, ft_djb2);
}

static t_map		*builtins(void)
{
	static t_map	*builtins_map = 0;

	if (!builtins_map)
	{
		builtins_map = (t_map *)ft_memalloc(sizeof(t_map));
		add_to_map(builtins_map, CD_COMMAND, b_cd);
		add_to_map(builtins_map, ENV_COMMAND, b_env);
		add_to_map(builtins_map, EXIT_COMMAND, b_exit);
		add_to_map(builtins_map, SETENV_COMMAND, b_setenv);
		add_to_map(builtins_map, UNSETENV_COMMAND, b_unsetenv);
		add_to_map(builtins_map, RAINBOW_COMMAND, b_rainbow);
	}
	return (builtins_map);
}

t_cmd				get_builtin_cmd(const char *command_name)
{
	t_cmd			cmd;

	cmd = (t_cmd)ft_map_get(*builtins(), (void *)command_name, ft_djb2);
	return (cmd);
}
