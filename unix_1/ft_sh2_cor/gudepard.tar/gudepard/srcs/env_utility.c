/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env_utility.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/28 08:30:23 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 20:52:15 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	env_add_and_exec(t_env *env, t_env *cpy, char **args, int clear)
{
	char	*key;
	char	*sep_index;
	size_t	i;

	i = 0;
	if (clear)
		ft_map_delete(cpy->vars, env_map_del);
	while (args[i])
	{
		sep_index = ft_strchr(args[i], '=');
		if (sep_index)
		{
			key = ft_strsub(args[i], 0, sep_index - args[i]);
			env_set(cpy, key, sep_index + 1);
			free(key);
		}
		else
		{
			exec_bin(cpy, env, args + i, 0);
			break ;
		}
		++i;
	}
}

void		env_utility(t_env *env, char **args, int ignore_inherit)
{
	t_env	*env_copy;

	env_copy = dup_env(env);
	env_add_and_exec(env, env_copy, args, ignore_inherit);
	free_env(env_copy);
}
