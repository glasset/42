/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   start_process.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 04:35:12 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 17:00:31 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void			exec_bin(t_env *env, t_env *p_env, char **args, int detached)
{
	char		*bin;
	int			command;
	const char	*error;

	command = (ft_strchr(*args, '/') == 0);
	bin = (command ? find_bin(p_env, *args) : find_bin2(p_env, *args));
	if (bin)
	{
		if (access(bin, X_OK) || is_dir(bin))
			shell_error(ERR_DENIED, *args);
		else
		{
			if (detached)
				start_detached(env, bin, args);
			else
				start_process(env, bin, args);
		}
	}
	else
	{
		error = (command ? ERR_COMMAND_NOT_FOUND : ERR_FILE_NON_EXISTING);
		shell_error(error, *args);
	}
	free(bin);
}

void			start_process(t_env *env, const char *path, char **args)
{
	pid_t		pid;

	pid = fork();
	if (pid == -1)
		shell_error(ERR_FORK_FAILED, 0);
	else
	{
		if (pid == 0)
		{
			start_detached(env, path, args);
			exit(1);
		}
		else
			waitpid(pid, 0, 0);
	}
}

void			start_detached(t_env *env, const char *path, char **args)
{
	char		**environ;

	environ = env_array(env);
	execve(path, args, environ);
	shell_error(ERR_UNKNOWN, path);
	char_array_free(environ);
}
