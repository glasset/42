/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lexer.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/22 16:21:52 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/24 19:10:43 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static int	read_token(char **stream, t_token *token)
{
	ignore_whitespace(stream);
	if (!**stream)
		return (0);
	if (read_operator(stream, token))
		return (1);
	if (read_word(stream, token))
		return (1);
	return (-1);
}

t_list		*tokenize(char *line)
{
	t_list	*tokens;
	t_token	token;
	int		ret;
	char	*err;
	t_list	*it;

	tokens = 0;
	while ((ret = read_token(&line, &token)) == 1)
		ft_lstappend(&tokens, ft_lstnew(&token, sizeof(t_token)));
	if (ret == -1)
	{
		err = ERR_SYNTAX_START;
		if (tokens)
		{
			it = tokens;
			while (it->next)
				it = it->next;
			err = ((t_token *)(it->content))->value;
		}
		shell_error(ERR_SYNTAX, err);
		ft_lstdel(&tokens, free_token);
	}
	return (tokens);
}
