/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   environ.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 06:03:29 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/21 19:32:24 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char			*join_env(const char *key, const char *value)
{
	char		*joined;
	size_t		key_len;
	size_t		value_len;

	key_len = ft_strlen(key);
	value_len = ft_strlen(value);
	joined = ft_strnew(key_len + value_len + 1);
	ft_strncpy(joined, key, key_len);
	ft_strncpy(joined + key_len, "=", 1);
	ft_strcpy(joined + key_len + 1, value);
	return (joined);
}

char			*env_get(t_env *env, const char *var_name)
{
	char		*value;

	value = (char *)ft_map_get(env->vars, (char *)var_name, ft_djb2);
	return (value);
}

void			env_set(t_env *env, const char *var_name, const char *new_value)
{
	t_map_entry	*old_entry;
	t_map_entry	entry;

	old_entry = ft_map_get_p(env->vars, (char *)var_name, ft_djb2);
	if (old_entry)
	{
		free(old_entry->value);
		old_entry->value = ft_strdup(new_value);
	}
	else
	{
		entry.key = ft_strdup(var_name);
		entry.value = ft_strdup(new_value);
		ft_map_insert(env->vars, entry, ft_djb2);
	}
}

void			env_remove(t_env *env, const char *var_name)
{
	ft_map_remove(env->vars, (char *)var_name, ft_djb2, env_map_del);
}

char			**env_array(t_env *env)
{
	char		**array;
	char		**iarray;
	size_t		map_size;

	map_size = 0;
	ft_map_foreach(env->vars, increment, &map_size);
	array = (char **)malloc(sizeof(char *) * (map_size + 1));
	array[map_size] = 0;
	iarray = array;
	ft_map_foreach(env->vars, map_add_env_to_array, &iarray);
	return (array);
}
