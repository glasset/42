/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ast2.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/26 17:51:36 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 18:08:35 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char		*ast_node_token_value(t_ast *node)
{
	t_token	*token;

	token = (t_token *)node->tokens->content;
	if (token)
		return (token->value);
	return (0);
}

void		ast_swap_tokens(t_ast *node1, t_ast *node2)
{
	t_list	*tokens_tmp;

	tokens_tmp = node1->tokens;
	node1->tokens = node2->tokens;
	node2->tokens = tokens_tmp;
}
