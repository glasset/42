/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/26 18:43:14 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 20:46:04 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

t_list		*read_heredoc(char *end_token, t_env *env)
{
	t_list	*list;
	char	*line;
	int		end;

	list = 0;
	end = 0;
	write(STDOUT, HEREDOC_PROMPT, sizeof(HEREDOC_PROMPT) - 1);
	env->heredoc = 1;
	while (env->heredoc && !end && get_next_line(STDIN, &line) == 1)
	{
		end = !ft_strcmp(line, end_token);
		if (!end && env->heredoc)
		{
			ft_lstappend(&list, ft_lstnew(line, ft_strlen(line) + 1));
			write(STDOUT, HEREDOC_PROMPT, sizeof(HEREDOC_PROMPT) - 1);
		}
		free(line);
	}
	if (!env->heredoc)
		ft_lstdel(&list, (t_deleter)free);
	env->heredoc = 0;
	return (list);
}

static void	dump_input(t_list *input, int fds[2])
{
	while (input)
	{
		write(fds[1], input->content, input->content_size - 1);
		write(fds[1], "\n", 1);
		input = input->next;
	}
	close_all(fds);
	exit(0);
}

void		dump_heredoc(t_ast *node, t_list *input, int fds[3], t_env *env)
{
	pid_t	pid;

	pid = fork();
	if (pid != -1)
	{
		if (pid == 0)
			dump_input(input, fds);
		else
		{
			dup2(fds[0], STDIN);
			dupif(fds[2], STDOUT);
			close_all(fds);
			closeif(fds[2]);
			ast_exec_cmd(node, env, 1);
			exit(1);
		}
	}
	else
		shell_error(ERR_FORK_FAILED, 0);
}

void		dump_heredoc_piped(t_ast *node, t_list *i, int fds[2], t_env *env)
{
	pid_t	pid;
	int		new_fds[6] = {-1, -1, -1, -1, -1, -1};

	if (!pipe(new_fds))
	{
		new_fds[2] = fds[0];
		new_fds[3] = fds[1];
		pid = fork();
		if (pid != -1)
		{
			if (pid == 0)
			{
				close_all(new_fds);
				dump_input(i, fds);
			}
			else
				pipe_ast_node(node, new_fds, env);
		}
		else
			shell_error(ERR_FORK_FAILED, 0);
	}
	else
		shell_error(ERR_PIPE_FAILED, 0);
}
