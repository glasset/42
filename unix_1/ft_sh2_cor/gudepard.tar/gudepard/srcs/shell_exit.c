/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shell_exit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 09:20:52 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/21 19:04:31 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	b_exit(t_env *env, size_t argc, char **args)
{
	UNUSED(argc);
	UNUSED(args);
	free_env(env);
	exit(0);
}
