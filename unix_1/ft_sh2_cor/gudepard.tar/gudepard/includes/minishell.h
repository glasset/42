/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gudepard <gudepard@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/22 03:40:18 by gudepard          #+#    #+#             */
/*   Updated: 2014/01/26 20:59:19 by gudepard         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include <sys/types.h>
# include <sys/stat.h>
# include <sys/wait.h>
# include <sys/uio.h>
# include <fcntl.h>
# include <dirent.h>
# include <signal.h>

# include "libft.h"

typedef struct stat		t_stat;
typedef struct dirent	t_dirent;

typedef struct s_env	t_env;

typedef struct s_ast		t_ast;
typedef enum e_token_type	t_token_type;
typedef struct s_token		t_token;

struct		s_env
{
	t_map	vars;
	int		running;
	int		heredoc;
};

# define VAR_PWD					"PWD"
# define VAR_OLDPWD					"OLDPWD"
# define VAR_HOME					"HOME"
# define VAR_PATH					"PATH"
# define VAR_PROMPT					"PROMPT"
# define VAR_SHELL_LVL				"SHLVL"
# define VAR_USER					"USER"
# define VAR_ENV_KEY_COLOR			"ENV_KEY_COLOR"
# define VAR_ENV_SEPARATOR_COLOR	"ENV_SEP_COLOR"
# define VAR_ENV_VALUE_COLOR		"ENV_VAL_COLOR"

void		init_env_vars(t_env *env);
t_env		*get_env(void);
void		free_env(t_env *env);
t_env		*dup_env(t_env *env);

void		env_map_del(void *key, void *value);
void		increment(void *data, void *count);
void		map_add_env_to_array(void *data, void *p_array);
void		map_copy_one(void *data, void *other_map);
void		map_print_env_one(void *data, void *p_env);

char		*join_env(const char *key, const char *value);
char		*env_get(t_env *env, const char *var_name);
void		env_set(t_env *env, const char *var_name, const char *new_value);
void		env_remove(t_env *env, const char *var_name);
char		**env_array(t_env *env);

void		print_env_one(t_env *env, const char *key, const char *value);
void		env_utility(t_env *env, char **args, int ignore_inherit);

size_t		char_array_map(char **array, size_t (*functor)(const char *));
size_t		char_array_len(char **array);
void		char_array_free(char **array);
char		**char_array_from_list(t_list *list);

char		*path_join(const char *head, const char *tail);
char		*str_list_join(t_list *list);
char		*reduce_path(t_env *env, const char *path);

# define APPEND_OFLAGS		(O_WRONLY | O_CREAT | O_APPEND)
# define TRUNC_OFLAGS		(O_WRONLY | O_CREAT | O_TRUNC)
# define CREATE_PERMISSIONS	(S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
int			open_file(const char *name, int oflags, mode_t mode);
int			is_valid_fd(int fd);

void		execute_line(char *line, t_env *env);
void		ast_exec_cmd(t_ast *node, t_env *env, int detached);

void		ast_exec_piped(t_ast *node, t_env *env, int fd_in);
void		pipe_ast_node(t_ast *node, int fds[4], t_env *env);
void		exec_one_piped(t_ast *node, t_env *env, int fds[4]);

void		ast_exec_r_redirect(t_ast *node, t_env *env, int oflags);
void		ast_exec_l_redirect(t_ast *node, t_env *env);
void		redirect_one(t_ast *cmd_node, int fds[2], t_env *env);
# define HEREDOC_PROMPT		"heredoc >"
void		ast_exec_heredoc(t_ast *node, t_env *env);
t_list		*read_heredoc(char *end_token, t_env *env);
void		dump_heredoc(t_ast *node, t_list *input, int fds[3], t_env *env);
void		dump_heredoc_piped(t_ast *node, t_list *i, int fds[2], t_env *env);

void		ambiguous_redirect_error(t_ast *node, int do_exit);

void		closeif(int fd);
void		close_all(int fds[2]);
void		dupif(int fd1, int fd2);

int			is_file(const char *full_path);
int			is_dir(const char *full_path);

char		*find_bin(t_env *env, const char *name);
char		*find_bin2(t_env *env, const char *name);

void		exec_bin(t_env *env, t_env *p_env, char **args, int detached);
void		start_process(t_env *env, const char *path, char **args);
void		start_detached(t_env *env, const char *path, char **args);

int			cd(t_env *env, const char *path);

char		*str_replace(const char *str, const char *old, const char *new);

/*
** Lexer - Parser
*/

# define WORD_CHARS		"!\"#$%%&'()*+,-./:=?@[]^_{}~"

struct		s_ast
{
	t_ast	*left;
	t_ast	*right;
	t_list	*tokens;
};

t_ast		*ast_new(t_token *token);
void		ast_free(t_ast *node);
void		ast_add_token_to_node(t_ast *node, t_token *token);
int			ast_is_node_type(t_ast *node, t_token_type type);
t_ast		*next_node_of_type(t_ast *node, t_token_type type);
char		*ast_node_token_value(t_ast *node);
void		ast_swap_tokens(t_ast *node1, t_ast *node2);

enum	e_token_type
{
	OP_SEMI_COLON,
	OP_PIPE,
	OP_REDIRECT_LEFT,
	OP_REDIRECT_RIGHT,
	OP_REDIRECT_LEFT2,
	OP_REDIRECT_RIGHT2,
	WORD
};

struct				s_token
{
	t_token_type	type;
	char			*value;
};

char		**tokens_as_char_array(t_list *tokens);
void		free_token(void *data, size_t size);

char		*extract_word(const char *start, size_t len);
void		ignore_whitespace(char **stream);
int			read_operator(char **stream, t_token *token);
int			read_word(char **stream, t_token *token);
t_list		*tokenize(char *line);

t_token		*get_token(t_list **tokens);
void		next_token(t_list **tokens);
t_ast		*parse_tokens(t_list *tokens);

int			parse_instruction(t_list **tokens, t_ast **node);
int			parse_exp(t_list **tokens, t_ast **node);

/*
** Prompt
*/
# define HOME_SHORTCUT "~"
# define DEFAULT_PROMPT "$ {6}%n {1}%c {255}> "

t_uint64	char_hash(const void *data);
t_map		*prompt_format_map(void);

void		prompt_format_c(t_env *env, t_list **str);
void		prompt_format_n(t_env *env, t_list **str);

typedef void (*t_prompt_proc)(t_env *, t_list **);

void		process_value(t_env *env, const char **fmt, t_list **str);
void		process_color(const char **fmt, t_list **str);

char		*format_prompt(t_env *env, const char *fmt);
void		show_prompt(t_env *env);

/*
** Error handling
*/
# define SHELL_ERROR_PREFIX "minishell"

# define ERR_FORK_FAILED		"failed to create a new process"
# define ERR_PIPE_FAILED		"failed to create a pipe"
# define ERR_FILE_NON_EXISTING	"no such file or directory"
# define ERR_DENIED				"permission denied"
# define ERR_UNKNOWN			"unknown error"
# define ERR_TOO_MANY_ARGS		"too many arguments"
# define ERR_TOO_FEW_ARGS		"missing arguments"
# define ERR_VAR_NON_EXISTING	"non existing key"
# define ERR_MISSING_DQUOTE		"missing dquote"
# define ERR_COMMAND_NOT_FOUND	"command not found"
# define ERR_NO_HOME			"no home directory set"
# define ERR_ILLEGAL_OPTION		"illegal option"
# define ERR_NOT_IN_PWD			"string not in pwd"
# define ERR_SYNTAX				"syntax error near"
# define ERR_SYNTAX_START		"<start>"
# define ERR_PARSE				"parse error near"
# define ERR_PARSE_END			"<end>"
# define ERR_AMBIGUOUS_REDIRECT	"ambiguous redirection at token"

void		shell_error(const char *what, const char *info);
void		builtin_error(const char *c, const char *type, const char *info);

void		on_sigint(int sig);

/*
** Builtins
*/
typedef void (*t_cmd)(t_env *, size_t, char **);

t_cmd		get_builtin_cmd(const char *command_name);

# define CD_COMMAND			"cd"
void		b_cd(t_env *env, size_t argc, char **args);
# define ENV_COMMAND		"env"
void		b_env(t_env *env, size_t argc, char **args);
# define EXIT_COMMAND		"exit"
void		b_exit(t_env *env, size_t argc, char **args);
# define SETENV_COMMAND		"setenv"
void		b_setenv(t_env *env, size_t argc, char **args);
# define UNSETENV_COMMAND	"unsetenv"
void		b_unsetenv(t_env *env, size_t argc, char **args);
# define RAINBOW_COMMAND	"rainbow"
void		b_rainbow(t_env *env, size_t argc, char **args);

#endif /* !MINISHELL_H */
