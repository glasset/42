/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glasset <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/11 13:01:43 by glasset           #+#    #+#             */
/*   Updated: 2014/02/13 16:51:16 by glasset          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <math.h>
#include "rtv.h"

void		norme(t_vec *l)
{
	double	len;

	len = sqrt(pow(l->x, 2.0) + pow(l->y, 2.0) + pow(l->z, 2.0));
	l->x = l->x / len;
	l->y = l->y / len;
	l->z = l->z / len;
}

void		init_ori_obj(t_vec *c, t_ray *l, t_obj *obj)
{
	c->x = l->ori.x - obj->point.x;
	c->y = l->ori.y - obj->point.y;
	c->z = l->ori.z - obj->point.z;
}

void		shor_plans(t_vec *shor, double a, double i)
{
	if (a < 0)
		return ;
	if (shor->x == -1.0)
	{
		shor->z = i;
		shor->x = a;
	}
	else if (a < shor->x)
	{
		shor->x = a;
		shor->z = i;
	}
}

void		shor_dist(double a, double b, t_vec  *shor, t_vec *c)
{
	if (c->x == 0.0)
	{
		shor->x = 0.0;
		shor->z = c->y;
		return ;
	}
	if (a >= 0 && b >= 0)
	{
		if (a > b)
			a = b;
	}
	else if (a < 0 && b < 0)
		return ;
	else if (a < 0)
		a = b;
	if (shor->x == -1.0)
	{
		shor->z = c->y;
		shor->x = a;
	}
	else if (a < shor->x)
	{
		shor->z = c->y;
		shor->x = a;
	}
}
